/*
 * Copyright (C) 2019-2020, Xilinx Inc - All rights reserved
 * Xilinx Resouce Management
 *
 * Licensed under the Apache License, Version 2.0 (the "License"). You may
 * not use this file except in compliance with the License. A copy of the
 * License is located at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations
 * under the License.
 */

#ifndef _XRM_VERSION_H_
#define _XRM_VERSION_H_

#define XRM_VERSION_STRING "1.0.116"
#define XRM_VERSION_RELEASE "202010"
#define XRM_GIT_BRANCH "2020.1"
#define XRM_GIT_COMMIT_HASH "a5b1165a8935198b80f04b20cf552a34bd6516d0"
#define XRM_GIT_COMMIT_DATE "Thu, 5 Nov 2020 22:50:05 -0800"

#endif // _XRM_VERSION_H_
